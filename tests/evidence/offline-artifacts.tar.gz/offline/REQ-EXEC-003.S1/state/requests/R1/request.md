{
  "request_id": "R1",
  "source": "source.txt",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator authorizes this exact offline request.",
  "actions": [
    {
      "id": "A",
      "source": "source.txt"
    },
    {
      "id": "B",
      "source": "source-b.txt"
    }
  ]
}

Bound generic package: binding/package/. Bound selected template: binding/template/. Content identities: binding/identities.json. Exact original input: original.json in case root.
