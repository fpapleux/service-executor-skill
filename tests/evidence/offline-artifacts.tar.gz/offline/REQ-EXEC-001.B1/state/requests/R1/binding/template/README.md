# Document export

Validate: [validate.md](validate.md). Decision: [decision.md](decision.md). Execute: [execute.md](execute.md). Report: [report.md](report.md). Tool documentation: [TOOLS.md](TOOLS.md).

Explicit local configuration: [TOOLS.md](TOOLS.md), [config.json](config.json).
