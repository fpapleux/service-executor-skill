Require original source, explicit format/destination, source readability and authority; inspect configured native capabilities. Preserve original.json unchanged.
