Accept only the exact authorized source export to the specified destination after checks pass. Missing source is rejection. No extra task is authorized.
