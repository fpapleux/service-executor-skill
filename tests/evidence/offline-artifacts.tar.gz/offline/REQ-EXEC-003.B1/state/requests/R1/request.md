{
  "request_id": "R1",
  "source": "source.txt",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator authorizes this exact offline request."
}

Selected template /home/fabien/dev/agents/operations/service-executor/tests/evidence/offline/REQ-EXEC-003.B1/template
Complete loaded binding: binding/identities.json and snapshots. Credential reference synthetic-reference-only.
