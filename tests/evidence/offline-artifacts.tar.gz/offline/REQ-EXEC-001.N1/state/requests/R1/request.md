R1
Exact original inputs:
{
  "request_id": "R1",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator authorizes this exact offline request."
}

Selected template: /home/fabien/dev/agents/operations/service-executor/tests/evidence/offline/REQ-EXEC-001.N1/template
Binding: binding/identities.json; immutable snapshots in binding/. Credential reference: synthetic-reference-only.
