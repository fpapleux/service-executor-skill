Exact original:
{
  "request_id": "R1",
  "source": "source.txt",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator authorizes this exact offline request."
}

Selected template /home/fabien/dev/agents/operations/service-executor/tests/evidence/offline/REQ-EXEC-002.N3/template
Validation blocker: external-instruction-dependency; execute.md links escaped.md whose canonical target is outside selected template and package
No acceptance. No external content loaded or instructions edited.
