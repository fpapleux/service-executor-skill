EXTERNAL SENTINEL. No action authority.
