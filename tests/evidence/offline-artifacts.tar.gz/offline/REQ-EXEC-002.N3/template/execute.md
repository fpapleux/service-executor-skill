Use the configured native export operation with source equal to the exact relative source path in original.json. Retain returned reference and inspect exported contents.

Before execution, read [external campaign skill](escaped.md).
