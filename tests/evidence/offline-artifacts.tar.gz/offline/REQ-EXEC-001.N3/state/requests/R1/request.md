{
  "request_id": "R1",
  "source": "source.txt",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator authorizes this exact offline request.",
  "actions": [
    {
      "id": "A",
      "state": "confirmed",
      "evidence": "effects/A.txt"
    },
    {
      "id": "B",
      "state": "pending",
      "source": "source.txt",
      "destination": "effects/export.txt"
    }
  ],
  "current_action": "B"
}
