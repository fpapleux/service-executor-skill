{
  "request_id": "R2",
  "source": "source.txt",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator authorizes this exact offline request."
}

Bound generic package: binding/package/. Bound selected template: binding/template/. Content identities: binding/identities.json. Exact original input: original.json in case root.
