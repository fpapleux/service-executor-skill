# Document export

Validate: [validate.md](validate.md). Decision: [decision.md](decision.md). Execute: [execute.md](execute.md). Report: [report.md](report.md). Tool documentation: [TOOLS.md](TOOLS.md).
