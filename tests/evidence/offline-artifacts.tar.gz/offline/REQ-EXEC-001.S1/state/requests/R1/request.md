# R1 — Document export

Original business input (preserved verbatim):

```json
{
  "request_id": "R1",
  "service": "document-export",
  "source": "source.txt",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator explicitly authorizes one exact source export and its customer-portal report."
}
```

Authority: Operator explicitly authorizes one exact source export and its customer-portal report.

Selected template: /home/fabien/dev/agents/operations/service-executor/tests/evidence/offline/REQ-EXEC-001.S1/template

Full binding: binding/manifest.json; effective configuration: binding/config.json. Credential reference: synthetic-reference-only. Exclusive OS request and resource locks are held by owner b5854580d1f44857b8991384e531d0aa.
