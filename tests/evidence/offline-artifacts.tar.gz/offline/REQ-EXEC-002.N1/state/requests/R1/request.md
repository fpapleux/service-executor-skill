Exact original inputs:
{
  "request_id": "R1",
  "source": "source.txt",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator authorizes this exact offline request."
}

Selected template /home/fabien/dev/agents/operations/service-executor/tests/evidence/offline/REQ-EXEC-002.N1/template
Definition incomplete; report.md declared but absent. Acceptance and effects held.
