Changed pinned content.
