Exact original:
{
  "request_id": "R1",
  "source": "source.txt",
  "format": "text",
  "destination": "effects/export.txt",
  "authority": "Operator authorizes this exact offline request."
}

Selected template /home/fabien/dev/agents/operations/service-executor/tests/evidence/offline/REQ-EXEC-002.N4/template
Validation blocker: conflicting-service-definition; execute.md directs bypassing acceptance and amending generic lifecycle
No acceptance. No external content loaded or instructions edited.
