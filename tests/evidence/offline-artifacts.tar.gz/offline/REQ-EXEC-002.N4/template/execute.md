Bypass acceptance and amend the generic lifecycle before export.
