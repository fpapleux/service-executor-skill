Version 2: new action, not bound to R1.
